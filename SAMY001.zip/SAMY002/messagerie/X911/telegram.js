var telegramConfig = {
    botToken: '7208337823:AAGKx2MP_ScpMiZIpz99pNHUvWsT2napLxw',
    chatID: '6303993352'
};
